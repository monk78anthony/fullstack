package main

import (
	"github.com/victorsteven/fullstack/api"
)

func main() {

	api.Run()

}
